


<?php $__env->startSection('title'); ?>
    Dashboard - Client
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10 my-5">            
            <?php echo $__env->make('partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="card card-default">  
                <div class="card-header"><h3 class="h3 d-inline-block text-info">Client Dashboard</h3><span class="float-right"><a href='<?php echo e(url("/jobs")); ?>/create'><button class="btn btn-info">Post a Job</button></a></span></div>
                <div class="card-body pt-0 table-responsive">
                   <?php if(count($jobs) > 0): ?>
                      <table class="table table-striped " id="jobTable">
                          <thead>
                            <tr>
                              <th>Job</th>
                              <th>Date Posted</th>
                              <th>Posted By</th>                  
                              <th></th>
                              <th></th>
                            </tr>
                          </thead>
                      <tbody>
                         <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <th scope="row"><h5 class="h5"><a href="<?php echo e(url('jobs')); ?>/<?php echo e($job->id); ?>" class="text-success"><?php echo e($job->title); ?></a></h5 ></th>
                            <td><small><?php echo e($job->created_at->diffForHumans()); ?></small></td>
                            <td><?php echo e($job->user->name); ?></td>
                            <td>
                              <i class="far fa-edit text-info" id="editJob" data-id="<?php echo e($job->id); ?>"></i>
                            </td>
                            <td>
                                 <i class="far fa-trash-alt text-danger" id="deleteJob" data-id="<?php echo e($job->id); ?>">
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p class="mt-5 text-center mb-5">You don't have any job post</p>
                        <?php endif; ?>
                      </tbody>
                    </table>
                    <?php echo e($jobs->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>