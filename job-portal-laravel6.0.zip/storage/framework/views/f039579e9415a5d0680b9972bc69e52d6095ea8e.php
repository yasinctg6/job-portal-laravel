

<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10 my-5">
            <?php echo $__env->make('partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="card card-default">
            	<div class="row">
	            	<div class="col-lg-3 p-4">
		            		<h4 class="h4 text-info">Select Category</h4>
		            		<form method="get">
			            		<div class="form-check">
								 <input class="form-check-input catFilter" type="checkbox"  value="all" id="filterall" name="cat"
								 <?php if($cat > 0): ?>
									<?php echo e('unchecked'); ?>

								 <?php else: ?> 
								 	<?php echo e('checked'); ?>	 	
								 <?php endif; ?>
								 >
								  <label class="form-check-label" for="filterall">All
								  </label>
								</div>
			            		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            		<div class="form-check">
									 <input class="form-check-input catFilter" type="checkbox" value="<?php echo e($category->id); ?>" id="defaultCheck1<?php echo e($category->id); ?>" name="cat"
									 <?php if($cat == $category->id): ?>
									 	<?php echo e('checked'); ?>

									 <?php endif; ?>	
									 >
									  <label class="form-check-label" for="defaultCheck1<?php echo e($category->id); ?>">
									   <?php echo e($category->category_name); ?>

									  </label>
									</div>
			            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


			            		<input type="text" name="search" class="form-control mt-2" placeholder="Search Job" value="<?php echo e($search); ?>">
			            		<button class="btn btn-success mt-2" id="searchCat">Seach</button>
		            		</form>
	            	</div>
	                <div class="card-body col-lg-9">
	                    <?php if(count($jobs) > 0): ?>
		                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    <div class="card mb-3">
		                        <h5 class="h5 card-header"><a href="<?php echo e(url('jobs')); ?>/<?php echo e($job->id); ?>" class="text-info"><?php echo e($job->title); ?></a></h5>
		                        <div class="card-block px-3">		                         
			                        <p class="small">
			                        	<span>Budget: &#36;<?php echo e($job->budget); ?></span>
			                        	<span> - </span>
			                        	<span>Posted: <?php echo e($job->created_at->diffForHumans()); ?></span>
			                        </p>
			                        <p class="small">
			                        	<span><span class="text-success"><i class="fas fa-briefcase"></i> Position Type:</span> <?php echo e(ucwords($job->position_type)); ?></span>	
			                        	<br>
			                        	<span><span class="text-success"><i class="fas fa-hourglass-end"></i> Project Duration:</span> <?php echo e(ucwords($job->project_duration)); ?></span>
			                        	<br>
			                        	<span><span class="text-success"><i class="fas fa-tags"></i> Category:</span> <?php echo e(ucwords($job->category->category_name)); ?></span>
			                        </p>
		                  	  </div>
		                    </div>	    
		                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                    <?php echo e($jobs->links()); ?>

		                <?php else: ?> 
		                	<h2 class="h2 text-muted text-center">NO RESULT FOUND</h2>
		                <?php endif; ?>
	                </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>