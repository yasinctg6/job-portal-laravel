<footer class="py-5" style="background-color: green">
	<div class="container">	
		<div class="row mt-5">
			<div class="col footer">
				<div class="col-sm copyright">
					<h6 class="h6">© 2020 Jobportal. All rights reserved</h6>
				</div>
				<div class="col-sm socialicons">
					<i class="px-1 fab fa-facebook fa-3x"></i>
					<i class="px-1 fab fa-twitter-square fa-3x"></i>
					<i class="px-1 fab fa-instagram fa-3x"></i>
					<i class="px-1 fab fa-google-plus-g fa-3x"></i>
					<i class="px-1 fab fa-linkedin fa-3x"></i>
					<i class="px-1 fab fa-pinterest-square fa-3x"></i>
				</div>
			</div>
		</div>
	</div>
</footer>